import re
from dataclasses import dataclass, field
from typing import List, Dict, Optional

@dataclass
class FortranUnit:
    """Represents a single Fortran program unit (PROGRAM / SUBROUTINE / FUNCTION)."""
    name: str
    unit_type: str          # PROGRAM / SUBROUTINE / FUNCTION
    source_file: str        # Originating filename
    raw_lines: List[str]    # Original source lines
    loc: int = 0            # Lines of code (non-blank, non-comment)
    common_blocks: List[str] = field(default_factory=list)  # Referenced COMMON block names
    context_header: str = ""  # COMMON + PARAMETER declarations prepended for LLM
    translated_java: Optional[str] = None
    confidence: str = "LOW"
    needs_review: bool = True

    def source(self) -> str:
        return "\n".join(self.raw_lines)

    def prompt_text(self) -> str:
        """Full text sent to LLM: context header + unit source."""
        if self.context_header:
            return f"{self.context_header}\n\n{self.source()}"
        return self.source()

class Fortran77Parser:
    """
    Parses Fortran 77 source into program units.
    Handles:
      - PROGRAM / SUBROUTINE / FUNCTION boundaries
      - COMMON block extraction
      - PARAMETER extraction
      - LOC counting (excluding blank lines and comments)
    """

    # Patterns for unit boundary detection
    UNIT_START = re.compile(
        r'^\s{0,6}(PROGRAM|SUBROUTINE|(?:REAL|INTEGER|DOUBLE\s+PRECISION|LOGICAL|CHARACTER)\s+FUNCTION|FUNCTION)\s+(\w+)',
        re.IGNORECASE
    )
    UNIT_END = re.compile(r'^\s{0,6}END\s*$', re.IGNORECASE)
    COMMON_DECL = re.compile(r'^\s{0,6}COMMON\s*/([\w]+)/', re.IGNORECASE)
    PARAM_DECL = re.compile(r'^\s{0,6}(PARAMETER|REAL PARAMETER|INTEGER PARAMETER)', re.IGNORECASE)
    COMMENT_LINE = re.compile(r'^[Cc*!]')
    CONTINUATION = re.compile(r'^     [^ 0]')  # column 6 continuation character

    def __init__(self, file_map: Dict[str, str]):
        """
        :param file_map: Dictionary mapping filename to file content
        """
        self.file_map = file_map
        self.units: List[FortranUnit] = []
        self.global_common_blocks: Dict[str, List[str]] = {}  # block_name -> [decl lines]
        self.global_parameters: List[str] = []

    def _is_comment(self, line: str) -> bool:
        return bool(self.COMMENT_LINE.match(line)) or line.strip() == ''

    def _count_loc(self, lines: List[str]) -> int:
        return sum(1 for l in lines if not self._is_comment(l) and l.strip())

    def _extract_common_refs(self, lines: List[str]) -> List[str]:
        """Find all COMMON block names referenced in this unit."""
        blocks = []
        for line in lines:
            m = self.COMMON_DECL.match(line)
            if m:
                bname = m.group(1).strip().upper()
                if bname not in blocks:
                    blocks.append(bname)
        return blocks

    def _build_context_header(self, common_block_names: List[str]) -> str:
        """Build a context string with COMMON block definitions for the LLM."""
        if not common_block_names and not self.global_parameters:
            return ""
        lines = ["C --- SHARED CONTEXT (COMMON BLOCKS & PARAMETERS) ---"]
        for bname in common_block_names:
            if bname in self.global_common_blocks:
                lines.extend(self.global_common_blocks[bname])
        if self.global_parameters:
            lines.extend(self.global_parameters)
        return "\n".join(lines)

    def _pre_scan_global_context(self):
        """
        First pass across ALL files: collect COMMON block definitions 
        and PARAMETER statements found outside units.
        """
        for filename, source in self.file_map.items():
            lines = source.splitlines()
            in_unit = False
            current_common = None
            for line in lines:
                if self.UNIT_START.match(line):
                    in_unit = True
                if in_unit:
                    continue
                # Track top-level COMMON block declarations
                m = self.COMMON_DECL.match(line)
                if m:
                    current_common = m.group(1).strip().upper()
                    if current_common not in self.global_common_blocks:
                        self.global_common_blocks[current_common] = []
                    self.global_common_blocks[current_common].append(line)
                elif current_common and self.CONTINUATION.match(line):
                    self.global_common_blocks[current_common].append(line)
                else:
                    current_common = None
                # Collect PARAMETER statements
                if self.PARAM_DECL.match(line):
                    self.global_parameters.append(line)

    def parse(self) -> List[FortranUnit]:
        """Main parse method. Returns list of FortranUnit objects."""
        self._pre_scan_global_context()

        for filename, source in self.file_map.items():
            lines = source.splitlines()
            current_lines = []
            current_name = None
            current_type = None
            in_unit = False

            for i, line in enumerate(lines):
                # Detect unit start
                m = self.UNIT_START.match(line)
                if m and not in_unit:
                    in_unit = True
                    # Parse unit type and name
                    raw_type = m.group(1).strip().upper()
                    if 'FUNCTION' in raw_type:
                        current_type = 'FUNCTION'
                    else:
                        current_type = raw_type
                    current_name = m.group(2).strip().upper()
                    current_lines = [line]
                    continue

                if in_unit:
                    current_lines.append(line)
                    # Detect unit end
                    if self.UNIT_END.match(line):
                        common_refs = self._extract_common_refs(current_lines)
                        ctx = self._build_context_header(common_refs)
                        unit = FortranUnit(
                            name=current_name,
                            unit_type=current_type,
                            source_file=filename,
                            raw_lines=current_lines,
                            loc=self._count_loc(current_lines),
                            common_blocks=common_refs,
                            context_header=ctx
                        )
                        self.units.append(unit)
                        current_lines = []
                        current_name = None
                        current_type = None
                        in_unit = False

        return self.units
