from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import gradio as gr
from ui import create_gradio_app

app = FastAPI(title="AAMP (Agentic Augmented Modernization Platform) API")

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Create Gradio app instance
gradio_app = create_gradio_app()

# Mount Gradio app on FastAPI root
app = gr.mount_gradio_app(app, gradio_app, path="/")

if __name__ == "__main__":
    import uvicorn
    # Make sure to run the uvicorn server against this file
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
