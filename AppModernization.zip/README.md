# Agentic Augmented Modernization Platform (AAMP)

## Overview
AAMP is a local, offline AI-agentic pipeline designed to perform a strictly "lift-and-shift" modernization of legacy Fortran code into Java 17 LTS. The project guarantees functional logic parity by utilizing an orchestrated graph of specialized Large Language Model (LLM) agents, culminating in an explicit Human-in-the-Loop developer gate to manually review complex interop abstractions.

## Tech Stack
*   **Backend & Orchestration:** Python, FastAPI, LangGraph, LangChain
*   **AI Engine:** Ollama running locally (currently configured for `gemma3:4b`)
*   **Frontend UI:** Gradio (mounted asynchronously onto FastAPI)

## Architecture Workflow
The pipeline runs a sequential graph with the following 6 AI nodes and 1 manual interrupt:

1.  **Agent 01 (Confidence Scanner):** Ingests Fortran (.f/.f90) and C++ headers, slicing them into blocks. Identifies complex constructs (`COMMON` blocks, `REAL*8`, `GOTO`) as `LOW` confidence and simple loops as `HIGH`.
2.  **Agent 02 (Auto Translator):** Automatically translates `HIGH` confidence blocks into flawless Java constructs.
3.  **Agent 03 (Assisted Translator):** Partially translates `LOW` confidence blocks while injecting explicit `// TODO:` inline markers where the AI is uncertain (e.g., JNI wrappers, memory pointers).
4.  **🛑 Human-in-the-Loop Gate:** The LangGraph execution pauses here. The Gradio UI surfaces the code. A human engineer manually fixes the `// TODO` items and approves the payload to resume the graph. (Approved java code is immediately saved to `output/ApprovedJava.java`).
5.  **Agent 04 (Java Validator):** A harsh critic LLM statically analyzes the semantic equivalence of the original Fortran versus the human-approved Java code.
6.  **Agent 05 (Code Profiler):** Analyzes the Java syntax for software maintainability and code smells.
7.  **Agent 06 (Parity Tester):** Shell execution agent that runs a live `javac` build against the generated `ApprovedJava.java`, appending `stderr` build feedback into the pipeline.

## Codebase Structure
*   `main.py` - Core execution point. Bootstraps FastAPI, configures CORS, and mounts the compiled Gradio UI instance.
*   `ui.py` - Constructs the physical `gr.Blocks` dashboard. Encompasses 4-step tab routing: File Ingestion ➔ Translation ➔ Code Edit / Resume Event ➔ Results.
*   `orchestrator.py` - The LangGraph StateGraph engine. Contains state reducers, the definitions for the 6 nodes, the sequential edge routing, and the `MemorySaver` thread interrupter to manage the human-in-the-loop pause state.
*   `agents.py` - Pure LangChain prompt engineering. Defines logic for invoking `ChatOllama` algorithms through `JsonOutputParser` structuring. 
*   `models.py` - Pydantic `BaseModel` and `TypedDict` implementations to ensure type-safe payload transmission as code blocks migrate through the node graph.
*   `requirements.txt` - Required environment dependencies.

## How to Run
Ensure you have Ollama installed and the `gemma3:4b` model downloaded locally (`ollama run gemma3:4b`).

1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Start the Uvicorn server:
   ```bash
   uvicorn main:app --reload
   ```
3. Access the dashboard via `http://localhost:8000`.
