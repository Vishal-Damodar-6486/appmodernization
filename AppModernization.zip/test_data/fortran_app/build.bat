@echo off
echo Building Fortran application with C++ Interop...

cd src
IF EXIST app.exe del app.exe

echo Compiling C++ interop...
g++ -c interop.cpp -o interop.o

echo Compiling Fortran modules...
gfortran -c common.f -o common.o
gfortran -c legacy_io.f -o legacy_io.o
gfortran -c math_ops.f -o math_ops.o
gfortran -c cpp_wrapper.f90 -o cpp_wrapper.o
gfortran -c main.f90 -o main.o

echo Linking...
gfortran -o app.exe main.o common.o legacy_io.o math_ops.o cpp_wrapper.o interop.o -lstdc++

echo Build complete. Output is in src\app.exe
echo Running the application...
echo --------------------------------------------------
app.exe
echo --------------------------------------------------
cd ..
