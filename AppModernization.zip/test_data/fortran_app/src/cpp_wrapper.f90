module cpp_interop
    use iso_c_binding
    implicit none
    
    interface
        subroutine process_sensor_data(raw_data, length, processed_data) bind(C, name="process_sensor_data")
            import :: C_DOUBLE, C_INT
            real(C_DOUBLE), intent(in) :: raw_data(*)
            integer(C_INT), intent(in) :: length
            real(C_DOUBLE), intent(out) :: processed_data(*)
        end subroutine process_sensor_data
    end interface
end module cpp_interop
