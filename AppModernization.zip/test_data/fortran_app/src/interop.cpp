#include <iostream>

extern "C" {
    // A simple C++ function to process sensor data to test C++ interop
    void process_sensor_data(double* raw_data, int* length, double* processed_data) {
        std::cout << "[C++ Module] Processing sensor data..." << std::endl;
        for (int i = 0; i < *length; ++i) {
            // Apply a simple dummy filter/transformation
            processed_data[i] = raw_data[i] * 0.95 + 1.2;
        }
    }
}
