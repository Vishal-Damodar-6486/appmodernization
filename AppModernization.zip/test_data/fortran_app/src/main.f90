program main
    use cpp_interop
    implicit none

    ! Common blocks
    real(8) :: r_lift, r_drag
    common /results/ r_lift, r_drag

    ! Sensor data for C++ module
    integer(4) :: data_len = 5
    real(8) :: raw_sensors(5) = [10.5d0, 12.1d0, 9.8d0, 11.0d0, 10.2d0]
    real(8) :: proc_sensors(5)

    print *, '--- AIRBUS LEGACY FLIGHT SIMULATOR (TEST APP) ---'
    
    ! 1. Legacy I/O: Read flight parameters
    print *, 'Reading flight parameters from input.dat...'
    call read_input()
    
    ! 2. Math Ops: Calculate aerodynamic forces
    print *, 'Calculating aerodynamic loads...'
    call calc_aero()
    
    ! 3. Legacy I/O: Print results
    call write_output()
    
    ! 4. C++ Interop: Process sensor data
    print *, 'Calling C++ module for sensor processing...'
    call process_sensor_data(raw_sensors, data_len, proc_sensors)
    
    print *, 'Processed sensor data: ', proc_sensors

    print *, '--- SIMULATION COMPLETE ---'
end program main
