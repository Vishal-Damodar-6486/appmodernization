import gradio as gr
import os
import uuid
from pathlib import Path
from orchestrator import build_graph

# Global variable to hold the compiled Graph app
graph_app = build_graph()

def ingest_directory(dir_path: str):
    if not os.path.isdir(dir_path):
        return f"Error: {dir_path} is not a valid directory.", ""
    
    files_found = []
    for root, _, files in os.walk(dir_path):
        for f in files:
            if f.endswith(('.f', '.f90', '.h', '.cpp')):
                files_found.append(os.path.join(root, f))
    
    tree_display = "\n".join(files_found)
    return f"Successfully found {len(files_found)} files in directory.", tree_display

def start_pipeline(dir_path: str):
    if not os.path.isdir(dir_path):
        return "Error: Invalid directory path.", "", [], ""
        
    session_id = str(uuid.uuid4())
    config = {"configurable": {"thread_id": session_id}}
    
    file_map = {}
    for root, _, files in os.walk(dir_path):
        for f in files:
            if f.endswith(('.f', '.f90', '.h', '.cpp')):
                try:
                    f_path = os.path.join(root, f)
                    with open(f_path, 'r', encoding='utf-8') as src_file:
                        # Use relative path as key for better readability
                        rel_path = os.path.relpath(f_path, dir_path)
                        file_map[rel_path] = src_file.read()
                except Exception as e:
                    print(f"Error reading {f}: {e}")
                    
    if not file_map:
        return "No source code found in directory.", "", [], ""

    initial_state = {
        "fortran_source": file_map,
        "agent_logs": [f"Pipeline Started. Ingested {len(file_map)} files."]
    }
    
    logs = []
    for event in graph_app.stream(initial_state, config, stream_mode="values"):
        if "agent_logs" in event:
            logs = event["agent_logs"]
            
    # Once paused at agent 04 (Human-in-the-Loop), get the intermediate state.
    state = graph_app.get_state(config)
    java_code = state.values.get("final_java_code", "// No code generated")
    blocks = state.values.get("code_blocks", [])
    
    # Format blocks for dataframe: ID, Name, Type, Source, Confidence
    block_data = [[b.id, b.name, b.unit_type, b.source_file, b.confidence] for b in blocks]
    
    formatted_logs = "\n".join(logs)
    return formatted_logs, java_code, block_data, session_id

def resume_pipeline(java_code: str, session_id: str):
    if not session_id:
        return "Error: No active session found.", "Please start the pipeline first."
        
    config = {"configurable": {"thread_id": session_id}}
    
    # Update state via Developer Gate modifications
    graph_app.update_state(config, {"final_java_code": java_code})
    
    # Save the approved file to disk
    os.makedirs("output", exist_ok=True)
    with open("output/ApprovedJava.java", "w") as f:
        f.write(java_code)
        
    logs = []
    # Resume the pipeline from interruption
    for event in graph_app.stream(None, config, stream_mode="values"):
        if "agent_logs" in event:
            logs = event["agent_logs"]
            
    state = graph_app.get_state(config)
    val_res = state.values.get("validation_results")
    if val_res:
        results = f"Score: {val_res.score}\nPassed: {val_res.passed}\nIssues: {val_res.issues}"
    else:
        results = "No validation results available."
        
    formatted_logs = "\n".join(logs)
    return formatted_logs, "File: output/ApprovedJava.java explicitly saved.\n\n" + results

def create_gradio_app() -> gr.Blocks:
    """Builds and returns the Gradio web interface for AAMP."""
    with gr.Blocks(title="AAMP Dashboard") as demo:
        # Session state to store thread_id
        session_id = gr.State("")
        gr.Markdown("# Agentic Augmented Modernization Platform (AAMP)")
        
        with gr.Tabs():
            with gr.Tab("Step 1: Configuration & Ingestion"):
                dir_input = gr.Textbox(label="Absolute Path to Fortran Root", placeholder="/path/to/fortran/code")
                ingest_btn = gr.Button("Fetch Files")
                status_box = gr.Textbox(label="Status", interactive=False)
                tree_box = gr.TextArea(label="Detected Files", interactive=False)
                
                ingest_btn.click(fn=ingest_directory, inputs=dir_input, outputs=[status_box, tree_box])
                
            with gr.Tab("Step 2 & 3: Translation & Developer Gate"):
                start_btn = gr.Button("Deploy Pipeline")
                
                with gr.Row():
                    with gr.Column(scale=1):
                        logs_box = gr.TextArea(label="Agent Status Tracker", interactive=False)
                    with gr.Column(scale=2):
                        gr.Markdown("### Scanner Dashboard (Confidence Logic)")
                        scanner_table = gr.Dataframe(
                            headers=["ID", "Name", "Type", "Source File", "Confidence"],
                            datatype=["str", "str", "str", "str", "str"],
                            label="Confidence Classification per Unit",
                            interactive=False
                        )
                
                gr.Markdown("### Review Agent 03 Output for LOW-Confidence Blocks")
                java_editor = gr.Code(label="Java Code (Fix // TODOs)", interactive=True)
                
                start_btn.click(
                    fn=start_pipeline, 
                    inputs=dir_input, 
                    outputs=[logs_box, java_editor, scanner_table, session_id]
                )
                
            with gr.Tab("Step 4: Validation & Output"):
                resume_btn = gr.Button("Approve Code & Resume Processing")
                final_logs = gr.TextArea(label="Validation Logs", interactive=False)
                final_results = gr.TextArea(label="Agent 04/05/06 Results", interactive=False)
                
                resume_btn.click(
                    fn=resume_pipeline, 
                    inputs=[java_editor, session_id], 
                    outputs=[final_logs, final_results]
                )
    return demo
