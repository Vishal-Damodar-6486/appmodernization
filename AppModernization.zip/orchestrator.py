from typing import TypedDict, Annotated, List, Dict
import operator
from langgraph.graph import StateGraph, END
from models import CodeBlock, ValidationResult
from parser_utils import Fortran77Parser

class GraphState(TypedDict):
    fortran_source: Dict[str, str] # filename -> content
    code_blocks: List[CodeBlock]
    final_java_code: str
    validation_results: ValidationResult
    agent_logs: List[str]

from agents import analyze_fortran_confidence, translate_high_confidence, translate_low_confidence_with_todos, validate_java_logic, profile_java_code
import subprocess
import os

def _append_log(state: GraphState, message: str) -> list[str]:
    logs = state.get("agent_logs")
    if not isinstance(logs, list): logs = []
    return logs + [message]

def agent_01_confidence_scanner(state: GraphState) -> dict: 
    file_map = state.get("fortran_source", {})
    parser = Fortran77Parser(file_map)
    units = parser.parse()
    
    blocks = []
    for unit in units:
        block = analyze_fortran_confidence(unit)
        blocks.append(block)
        
    return {"code_blocks": blocks, "agent_logs": _append_log(state, f"Agent 01: Parsed {len(units)} units from {len(file_map)} files.")}

def agent_02_auto_translator(state: GraphState) -> dict: 
    blocks = state.get("code_blocks", [])
    translated_count = 0
    for b in blocks:
        if b.confidence == "HIGH":
            b.translated_java = translate_high_confidence(b)
            translated_count += 1
    return {"code_blocks": blocks, "agent_logs": _append_log(state, f"Agent 02: Auto-translated {translated_count} HIGH blocks.")}

def agent_03_assisted_translator(state: GraphState) -> dict: 
    blocks = state.get("code_blocks", [])
    translated_count = 0
    java_parts = []
    
    for b in blocks:
        if b.confidence == "LOW":
            b.translated_java = translate_low_confidence_with_todos(b)
            translated_count += 1
        if b.translated_java:
            java_parts.append(b.translated_java)
            
    # Combine code into final Java
    final_java = "\n\n".join(java_parts)
    return {
        "code_blocks": blocks, 
        "final_java_code": final_java,
        "agent_logs": _append_log(state, f"Agent 03: Processed {translated_count} LOW blocks with TODOs.")
    }

def agent_04_java_validator(state: GraphState) -> dict:
    file_map = state.get("fortran_source", {})
    # Combine all fortran source for global validation context
    combined_fortran = "\n\n".join(file_map.values())
    java_code = state.get("final_java_code", "")
    val_res = validate_java_logic(combined_fortran, java_code)
    return {"validation_results": val_res, "agent_logs": _append_log(state, f"Agent 04: Validation Score {val_res.score}")}

def agent_05_code_profiler(state: GraphState) -> dict: 
    java_code = state.get("final_java_code", "")
    issues = profile_java_code(java_code)
    val_res = state.get("validation_results")
    if val_res and issues:
        temp_issues = list(val_res.issues)
        temp_issues.extend(issues)
        val_res.issues = temp_issues
    return {"validation_results": val_res, "agent_logs": _append_log(state, f"Agent 05: Found {len(issues)} smells.")}

def agent_06_parity_tester(state: GraphState) -> dict: 
    # Actually compile the java code
    java_code = state.get("final_java_code", "")
    log_msg = "Agent 06: Compiled successfully."
    
    # Write to a temp file and compile
    with open("MainTranslation.java", "w") as f:
        f.write(java_code)
        
    try:
        compile_result = subprocess.run(["javac", "MainTranslation.java"], capture_output=True, text=True)
        if compile_result.returncode != 0:
            log_msg = f"Agent 06 Build Failed: {compile_result.stderr}"
    except Exception as e:
        log_msg = f"Agent 06 Error running javac: {e}"
        
    return {"agent_logs": _append_log(state, log_msg)}

def build_graph():
    workflow = StateGraph(GraphState)
    
    # Add Nodes
    workflow.add_node("agent_01", agent_01_confidence_scanner)
    workflow.add_node("agent_02", agent_02_auto_translator)
    workflow.add_node("agent_03", agent_03_assisted_translator)
    workflow.add_node("agent_04", agent_04_java_validator)
    workflow.add_node("agent_05", agent_05_code_profiler)
    workflow.add_node("agent_06", agent_06_parity_tester)
    
    # Add Edges (Sequential Pipeline)
    workflow.set_entry_point("agent_01")
    workflow.add_edge("agent_01", "agent_02")
    workflow.add_edge("agent_02", "agent_03")
    workflow.add_edge("agent_03", "agent_04") # Pipeline will pause before entering agent_04
    workflow.add_edge("agent_04", "agent_05")
    workflow.add_edge("agent_05", "agent_06")
    workflow.add_edge("agent_06", END)
    
    # Compile with memory to allow human-in-the-loop interrupt
    from langgraph.checkpoint.memory import MemorySaver
    memory = MemorySaver()
    app = workflow.compile(
        checkpointer=memory,
        interrupt_before=["agent_04"] # Pause execution here for the developer review
    )
    return app

