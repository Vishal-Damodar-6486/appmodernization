from langchain_ollama import ChatOllama
from langchain_core.messages import SystemMessage, HumanMessage
from parser_utils import FortranUnit

# Primary LLM instance configuring the local gemma3:4b model
llm = ChatOllama(model="gemma3:4b", temperature=0)

def test_connection():
    """Verify local Ollama engine is reachable."""
    try:
        return llm.invoke([HumanMessage(content="system test")]).content
    except Exception as e:
        return f"Error: {e}"

from langchain_core.output_parsers import JsonOutputParser
from models import CodeBlock

def analyze_fortran_confidence(unit: FortranUnit) -> CodeBlock:
    """Agent 01: Scans a single Fortran unit and classifies it into HIGH or LOW confidence."""
    system_prompt = (
        "You are an expert Fortran to Java modernization engineer.\n"
        "Analyze the provided Fortran unit logic.\n"
        "Classify translation confidence as 'HIGH' or 'LOW'.\n"
        "- LOW confidence: COMMON blocks, REAL*8, DOUBLE PRECISION, GOTO, implicit typing, C++ interop.\n"
        "- HIGH confidence: Standard DO loops, simple assignment, basic IF/THEN/ELSE.\n\n"
        "Return a JSON object where each object has:\n"
        '- "confidence": "HIGH" or "LOW"\n'
        '- "needs_review": true if LOW, false if HIGH\n'
    )
    
    parser = JsonOutputParser()
    prompt = system_prompt + f"\n\nUnit Name: {unit.name}\nUnit Type: {unit.unit_type}\n\nFormat strictly as JSON.\n\nCode to analyze:\n" + unit.prompt_text()
    
    try:
        response = llm.invoke([HumanMessage(content=prompt)])
        parsed = parser.invoke(response)
        
        return CodeBlock(
            id=f"blk_{unit.name}",
            name=unit.name,
            unit_type=unit.unit_type,
            source_file=unit.source_file,
            original_code=unit.source(),
            confidence=parsed.get("confidence", "LOW"),
            needs_review=parsed.get("needs_review", True)
        )
    except Exception as e:
        print(f"Agent 01 error for {unit.name}: {e}")
        return CodeBlock(
            id=f"blk_{unit.name}",
            name=unit.name,
            unit_type=unit.unit_type,
            source_file=unit.source_file,
            original_code=unit.source(),
            confidence="LOW",
            needs_review=True
        )

def translate_high_confidence(block: CodeBlock) -> str:
    """Agent 02: Translates HIGH confidence Fortran blocks directly to Java."""
    system_prompt = (
        "You are an expert modernization engineer translating Fortran to Java.\n"
        "Translate the following HIGH confidence Fortran code to Java.\n"
        "Output ONLY the raw Java code without markdown formatting or conversational text."
    )
    prompt = system_prompt + "\n\nFortran Code:\n" + block.original_code
    
    try:
        response = llm.invoke([HumanMessage(content=prompt)])
        return response.content.strip().replace("```java", "").replace("```", "")
    except Exception as e:
        print(f"Agent 02 Error: {e}")
        return f"// Translation Failed: {e}"

def translate_low_confidence_with_todos(block: CodeBlock) -> str:
    """Agent 03: Translates LOW confidence blocks to Java, adding explicit // TODOs for human review."""
    system_prompt = (
        "You are an expert modernization engineer translating Fortran to Java.\n"
        "This Fortran code contains complex legacy constructs (e.g. COMMON blocks, REAL*8, interop).\n"
        "Translate what you can safely, but you MUST insert explicit `// TODO: ` comments "
        "at areas where human intervention is required.\n"
        "Output ONLY the raw Java code without markdown formatting or conversational text."
    )
    prompt = system_prompt + "\n\nFortran Code:\n" + block.original_code
    
    try:
        response = llm.invoke([HumanMessage(content=prompt)])
        return response.content.strip().replace("```java", "").replace("```", "")
    except Exception as e:
        print(f"Agent 03 Error: {e}")
        return f"// Translation Failed: {e}\n// TODO: Manually translate this block."

from models import ValidationResult

def validate_java_logic(original_fortran: str, java_code: str) -> ValidationResult:
    """Agent 04: Validates the logical parity of the newly translated Java against the Original Fortran."""
    system_prompt = (
        "You are a strict code reviewer.\n"
        "Compare the original Fortran code with the provided Java translation.\n"
        "Check for logical parity, precision issues, and correct handling of legacy constructs.\n"
        "Return a JSON object with:\n"
        '- "score": integer 0-100\n'
        '- "passed": boolean (true if score > 80)\n'
        '- "issues": list of string strings detailing any bugs found'
    )
    prompt = f"{system_prompt}\n\nFortran:\n{original_fortran}\n\nJava:\n{java_code}"
    parser = JsonOutputParser()
    try:
        response = llm.invoke([HumanMessage(content=prompt)])
        parsed = parser.invoke(response)
        return ValidationResult(
            score=parsed.get("score", 0),
            passed=parsed.get("passed", False),
            issues=parsed.get("issues", ["Validation parsing failed"])
        )
    except Exception as e:
        print(f"Agent 04 Error: {e}")
        return ValidationResult(score=0, passed=False, issues=[f"Exception: {e}"])

def profile_java_code(java_code: str) -> list:
    """Agent 05: Scans Java for code smells and maintainability."""
    system_prompt = (
        "You are a Senior Java Architect.\n"
        "Review this Java code for quality, performance, and best practices.\n"
        "List any code smells or maintainability issues as a JSON array of strings. Do not include markdown blocks."
    )
    parser = JsonOutputParser()
    try:
        response = llm.invoke([HumanMessage(content=system_prompt + "\n\n" + java_code)])
        parsed = parser.invoke(response)
        if isinstance(parsed, list):
            return [str(x) for x in parsed]
        return ["Unable to parse profiler output."]
    except Exception as e:
        print(f"Agent 05 Error: {e}")
        return [f"Profiler exception: {e}"]

