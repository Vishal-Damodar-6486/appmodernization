from pydantic import BaseModel, Field
from typing import List, Optional, Literal

class CodeBlock(BaseModel):
    id: str
    name: str = "UNKNOWN"
    unit_type: str = "UNKNOWN"
    source_file: str = "UNKNOWN"
    original_code: str
    confidence: Literal["HIGH", "LOW"]
    translated_java: Optional[str] = None
    needs_review: bool = False
    
class AgentResult(BaseModel):
    success: bool
    message: str

class ValidationResult(BaseModel):
    score: int = Field(ge=0, le=100)
    passed: bool
    issues: List[str] = []
